import 'package:projekt/graph_data_lists.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class LiveData {
  LiveData(this.value, this.time);

  final double value;
  final double time;

  static LiveData returnMax(LiveData a, LiveData b) {
    if (a.value >= b.value) {
      return a;
    }
    return b;
  }

  static LiveData returnMin(LiveData a, LiveData b) {
    if (a.value <= b.value) {
      return a;
    }
    return b;
  }
}

class LiveDataList {
  LiveDataList();

  ChartSeriesController? chartSeriesController;
  List<LiveData> data = [];

  LiveData valMax = LiveData(0, 0);
  LiveData valMin = LiveData(double.maxFinite, 0);
  double valAvg = 0;
  double sumVal = 0;

  void addDataPoint(double value, double time) {
    data.add(LiveData(value, time));
    chartSeriesController?.updateDataSource(addedDataIndex: data.length - 1);

    valMax = LiveData.returnMax(valMax, data[data.length - 1]);
    valMin = LiveData.returnMin(valMin, data[data.length - 1]);
    sumVal += data[data.length - 1].value;
    valAvg = sumVal/data.length;

    GraphDataLists.notifyParent!();
  }

  void deleteDataPoints() {
    chartSeriesController?.updateDataSource(
        removedDataIndexes: [for (var i = 0; i < data.length; i++) i]);
    data.clear();
    valMax = LiveData(0, 0);
    valMin = LiveData(double.maxFinite, 0);
    valAvg = 0;
    sumVal = 0;

    GraphDataLists.notifyParent!();
  }
}
