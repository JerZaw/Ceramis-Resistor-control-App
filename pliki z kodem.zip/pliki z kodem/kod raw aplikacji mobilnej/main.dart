import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'mqtt.dart';
import 'live_graph.dart';
import 'graph_data_lists.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  final myHomePage = const MyHomePage(title: 'MiS temperaturą rezystora');

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sterowanie',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: myHomePage,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int goalTemperature = 0;
  bool temperatureSent = false;
  bool dataIntervalSent = false;
  int dataInterval = 2;
  int _selectedItemIndex = 0;

  void setStateCallback() {
    setState(() {});
  }

  final TextEditingController _goalTemperaturecontroller =
      TextEditingController(text: "0");
  final TextEditingController _dataIntervalcontroller =
      TextEditingController(text: "2");

  final client =
      MqttServerClient('test.mosquitto.org', 'jerzix-raspberry-python');

  void controlToggleButton() {
    GraphDataLists.controlOn = !GraphDataLists.controlOn;
    sendControlStart(GraphDataLists.controlOn);
    setState(() {});
  }

  void resetButton() {
    GraphDataLists.goalTempList.deleteDataPoints();
    GraphDataLists.currentTempList.deleteDataPoints();
    GraphDataLists.controlPWMList.deleteDataPoints();
    GraphDataLists.controlCurrentList.deleteDataPoints();
    GraphDataLists.currentTemperature = 0;
    GraphDataLists.currentOnResistor = 0;
    GraphDataLists.controlPWM = 0;

    goalTemperature = 0;
    _goalTemperaturecontroller.text = goalTemperature.toString();
    GraphDataLists.controlOn = false;
    temperatureSent = false;
    dataIntervalSent = false;
    dataInterval = 2;
    _dataIntervalcontroller.text = dataInterval.toString();

    sendTemperature(goalTemperature);
    sendDataInterval(dataInterval);
    sendControlStart(GraphDataLists.controlOn, shouldReset: true);

    setState(() {});
  }

  void sendControlStart(bool controlStart, {bool shouldReset = false}) {
    //send control start/stop information
    String topic = "control";
    String data =
        '{"control_start": ${toInt(GraphDataLists.controlOn)}, "should_reset": ${toInt(shouldReset)}}';
    customPublish(topic, data, client);
    sendTemperature(goalTemperature);
  }

  void sendTemperature(int newTemperature) {
    //send temperature needed
    String topic = "temperature";
    String data;
    if (GraphDataLists.controlOn) {
      data = '{"goal_temperature": $newTemperature}';
    } else {
      data = '{"goal_temperature": 0}';
    }

    customPublish(topic, data, client);
    temperatureSent = true;
    setState(() {});
  }

  void sendDataInterval(int newDataInterval) {
    //send temperature needed
    String topic = "dataInterval";
    String data = '{"data_interval": $dataInterval}';
    customPublish(topic, data, client);
    dataIntervalSent = true;
    setState(() {});
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedItemIndex = index;
    });
  }

  Widget statisticalData() {
    switch (_selectedItemIndex) {
      case 0:
        return temperatureGraph;
      case 1:
        return currentGraph;
      case 2:
        return pWMGraph;
      case 3:
        return statisticalDataPresentation;
      default:
        return const Text("ERROR");
    }
  }

  late LineTemperatureGraph temperatureGraph;
  late LineCurrentGraph currentGraph;
  late LinePWMGraph pWMGraph;
  late StatisticalDataPresentation statisticalDataPresentation;

  void initializeMqtt() async {
    await mqttSetup(client);
    sendTemperature(goalTemperature);
    sendDataInterval(dataInterval);
    sendControlStart(GraphDataLists.controlOn);
  }

  @override
  void initState() {
    temperatureGraph = LineTemperatureGraph(notifyParent: setStateCallback);
    currentGraph = LineCurrentGraph(notifyParent: setStateCallback);
    pWMGraph = LinePWMGraph(notifyParent: setStateCallback);
    statisticalDataPresentation =
        StatisticalDataPresentation(notifyParent: setStateCallback);
    super.initState();
    initializeMqtt();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        // Add a ListView to the drawer. This ensures the user can scroll
        // through the options in the drawer if there isn't enough vertical
        // space to fit everything.
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            const SizedBox(
              height: 90,
              child: DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.blue,
                ),
                child: Text('Wybierz Statystykę'),
              ),
            ),
            ListTile(
              title: Text(
                'Śledzenie Temperatury',
                style: TextStyle(
                    fontWeight: _selectedItemIndex == 0
                        ? FontWeight.w900
                        : FontWeight.normal),
              ),
              selected: _selectedItemIndex == 0,
              selectedTileColor: Colors.purpleAccent.shade100,
              selectedColor: Colors.purple.shade900,
              onTap: () {
                _onItemTapped(0);
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text(
                'Śledzenie Prądu',
                style: TextStyle(
                    fontWeight: _selectedItemIndex == 1
                        ? FontWeight.w900
                        : FontWeight.normal),
              ),
              selected: _selectedItemIndex == 1,
              selectedTileColor: Colors.purpleAccent.shade100,
              selectedColor: Colors.purple.shade900,
              onTap: () {
                _onItemTapped(1);
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text(
                'Śledzenie PWM',
                style: TextStyle(
                    fontWeight: _selectedItemIndex == 2
                        ? FontWeight.w900
                        : FontWeight.normal),
              ),
              selected: _selectedItemIndex == 2,
              selectedTileColor: Colors.purpleAccent.shade100,
              selectedColor: Colors.purple.shade900,
              onTap: () {
                _onItemTapped(2);
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text(
                'Statystyki Obliczeniowe',
                style: TextStyle(
                    fontWeight: _selectedItemIndex == 3
                        ? FontWeight.w900
                        : FontWeight.normal),
              ),
              selected: _selectedItemIndex == 3,
              selectedTileColor: Colors.purpleAccent.shade100,
              selectedColor: Colors.purple.shade900,
              onTap: () {
                _onItemTapped(3);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Flexible(flex: 10, child: statisticalData()),
            Flexible(
                flex: 8,
                child: Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                        children: [
                          const Text("MONITOROWANIE"),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              const Text("Interwał zbierania danych:"),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      SizedBox(
                                        width: 30,
                                        child: TextField(
                                          inputFormatters: [
                                            LengthLimitingTextInputFormatter(2)
                                          ],
                                          controller: _dataIntervalcontroller,
                                          onChanged: (text) {
                                            dataInterval = int.parse(text);
                                            dataIntervalSent = false;
                                            setState(() {});
                                          },
                                          decoration: const InputDecoration(
                                            contentPadding:
                                                EdgeInsets.symmetric(vertical: 5),
                                            isDense: true,
                                          ),
                                          textAlign: TextAlign.center,
                                          keyboardType: TextInputType.number,
                                        ),
                                      ),
                                      const Text("s"),
                                    ],
                                  ),
                                  IconButton(
                                      onPressed: () {
                                        sendDataInterval(dataInterval);
                                      },
                                      icon: Icon(
                                        Icons.check_circle_outline,
                                        color: dataIntervalSent
                                            ? Colors.green
                                            : Colors.red,
                                      )),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              const Text("Aktualna temperatura: "),
                              Row(
                                children: [
                                  Text(GraphDataLists.currentTemperature
                                      .toString()),
                                  const SizedBox(width: 2),
                                  const Text("\u2103"),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              const Text("Prąd na rezystorze grzejącym:"),
                              Row(
                                children: [
                                  Text(GraphDataLists.currentOnResistor
                                      .toString()),
                                  const SizedBox(width: 2),
                                  const Text("mA"),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          const Text("STEROWANIE"),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              const Text("Zadana temperatura: "),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      SizedBox(
                                        width: 30,
                                        child: TextField(
                                          inputFormatters: [
                                            LengthLimitingTextInputFormatter(2)
                                          ],
                                          controller: _goalTemperaturecontroller,
                                          onChanged: (text) {
                                            goalTemperature = int.parse(text);
                                            temperatureSent = false;
                                          },
                                          decoration: const InputDecoration(
                                            contentPadding:
                                                EdgeInsets.symmetric(vertical: 5),
                                            isDense: true,
                                          ),
                                          textAlign: TextAlign.center,
                                          keyboardType: TextInputType.number,
                                        ),
                                      ),
                                      const Text("\u2103"),
                                    ],
                                  ),
                                  IconButton(
                                    onPressed: () {
                                      sendTemperature(goalTemperature);
                                    },
                                    icon: Icon(
                                      Icons.check_circle_outline,
                                      color: temperatureSent
                                          ? Colors.green
                                          : Colors.red,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              SizedBox(
                                width: 100,
                                child: ElevatedButton(
                                  onPressed: controlToggleButton,
                                  child: Text(
                                    GraphDataLists.controlOn ? "STOP" : "START",
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 100,
                                child: ElevatedButton(
                                  onPressed: resetButton,
                                  child: const Text(
                                    "RESET",
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                        ],
                      ),
                    ],
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
