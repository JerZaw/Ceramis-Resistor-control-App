import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'live_data.dart';
import 'graph_data_lists.dart';

class LineTemperatureGraph extends StatefulWidget {
  final Function() notifyParent;

  const LineTemperatureGraph({super.key, required this.notifyParent});

  @override
  State<LineTemperatureGraph> createState() => _LineTemperatureGraphState();
}

class _LineTemperatureGraphState extends State<LineTemperatureGraph> {
  late ZoomPanBehavior zoomPanBehavior;

  @override
  void initState() {
    zoomPanBehavior = ZoomPanBehavior(
      enablePinching: true,
      enableDoubleTapZooming: true,
      enablePanning: true,
    );
    GraphDataLists.notifyParent = widget.notifyParent;

    super.initState();
  }

  @override
  void dispose() {
    GraphDataLists.currentTempList.chartSeriesController = null;
    GraphDataLists.goalTempList.chartSeriesController = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: MediaQuery.of(context).size.width - 20,
        // height: MediaQuery.of(context).size.height / 2,
        child: SfCartesianChart(
          zoomPanBehavior: zoomPanBehavior,
          enableAxisAnimation: true,
          legend: const Legend(
            isVisible: true,
            position: LegendPosition.bottom,
          ),
          primaryXAxis: NumericAxis(
            minimum: 0,
            title: AxisTitle(
              text: "Czas (s)",
            ),
          ),
          primaryYAxis: NumericAxis(
            title: AxisTitle(
              text: "Temperatura (\u2103)",
            ),
            // anchorRangeToVisiblePoints: true
            minimum: 20,
          ),
          series: <ChartSeries>[
            // Renders step line chart
            StepLineSeries<LiveData, double>(
              name: "Zadana",
              dataSource: GraphDataLists.goalTempList.data,
              xValueMapper: (LiveData data, _) => data.time,
              yValueMapper: (LiveData data, _) => data.value,
              onRendererCreated: (ChartSeriesController controller) {
                GraphDataLists.goalTempList.chartSeriesController = controller;
              },
            ),
            StepLineSeries<LiveData, double>(
              name: "Zmierzona",
              dataSource: GraphDataLists.currentTempList.data,
              xValueMapper: (LiveData data, _) => data.time,
              yValueMapper: (LiveData data, _) => data.value,
              onRendererCreated: (ChartSeriesController controller) {
                GraphDataLists.currentTempList.chartSeriesController =
                    controller;
              },
            ),
          ],
        ),
      ),
    );
  }
}

class LineCurrentGraph extends StatefulWidget {
  final Function() notifyParent;

  const LineCurrentGraph({super.key, required this.notifyParent});

  @override
  State<LineCurrentGraph> createState() => _LineCurrentGraphState();
}

class _LineCurrentGraphState extends State<LineCurrentGraph> {
  late ZoomPanBehavior zoomPanBehavior;

  @override
  void initState() {
    zoomPanBehavior = ZoomPanBehavior(
      enablePinching: true,
      enableDoubleTapZooming: true,
      enablePanning: true,
    );
    GraphDataLists.notifyParent = widget.notifyParent;

    super.initState();
  }

  @override
  void dispose() {
    GraphDataLists.controlCurrentList.chartSeriesController = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: MediaQuery.of(context).size.width - 20,
        // height: MediaQuery.of(context).size.height / 2,
        child: SfCartesianChart(
          zoomPanBehavior: zoomPanBehavior,
          enableAxisAnimation: true,
          legend: const Legend(
            isVisible: true,
            position: LegendPosition.bottom,
          ),
          primaryXAxis: NumericAxis(
            minimum: 0,
            title: AxisTitle(
              text: "Czas (s)",
            ),
          ),
          primaryYAxis: NumericAxis(
            title: AxisTitle(
              text: "Prąd (mA)",
            ),
            // anchorRangeToVisiblePoints: true
            minimum: 0,
            // maximum: 170,
          ),
          series: <ChartSeries>[
            // Renders step line chart
            StepLineSeries<LiveData, double>(
              name: "Na rezystorze grzejącym",
              dataSource: GraphDataLists.controlCurrentList.data,
              xValueMapper: (LiveData data, _) => data.time,
              yValueMapper: (LiveData data, _) => data.value,
              onRendererCreated: (ChartSeriesController controller) {
                GraphDataLists.controlCurrentList.chartSeriesController =
                    controller;
              },
            ),
          ],
        ),
      ),
    );
  }
}

class LinePWMGraph extends StatefulWidget {
  final Function() notifyParent;

  const LinePWMGraph({super.key, required this.notifyParent});

  @override
  State<LinePWMGraph> createState() => _LinePWMGraphState();
}

class _LinePWMGraphState extends State<LinePWMGraph> {
  late ZoomPanBehavior zoomPanBehavior;

  @override
  void initState() {
    zoomPanBehavior = ZoomPanBehavior(
      enablePinching: true,
      enableDoubleTapZooming: true,
      enablePanning: true,
    );
    GraphDataLists.notifyParent = widget.notifyParent;

    super.initState();
  }

  @override
  void dispose() {
    GraphDataLists.controlPWMList.chartSeriesController = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: MediaQuery.of(context).size.width - 20,
        // height: MediaQuery.of(context).size.height / 2,
        child: SfCartesianChart(
          zoomPanBehavior: zoomPanBehavior,
          enableAxisAnimation: true,
          legend: const Legend(
            isVisible: true,
            position: LegendPosition.bottom,
          ),
          primaryXAxis: NumericAxis(
            minimum: 0,
            title: AxisTitle(
              text: "Czas (s)",
            ),
          ),
          primaryYAxis: NumericAxis(
            title: AxisTitle(
              text: "Wypełnienie PWM (%)",
            ),
            // anchorRangeToVisiblePoints: true
            minimum: 0,
            maximum: 100,
          ),
          series: <ChartSeries>[
            // Renders step line chart
            StepLineSeries<LiveData, double>(
              name: "PWM sterujący bazą tranzystora",
              dataSource: GraphDataLists.controlPWMList.data,
              xValueMapper: (LiveData data, _) => data.time,
              yValueMapper: (LiveData data, _) => data.value,
              onRendererCreated: (ChartSeriesController controller) {
                GraphDataLists.controlPWMList.chartSeriesController =
                    controller;
              },
            ),
          ],
        ),
      ),
    );
  }
}

class StatisticalDataPresentation extends StatefulWidget {
  final Function() notifyParent;

  const StatisticalDataPresentation({super.key, required this.notifyParent});

  @override
  State<StatisticalDataPresentation> createState() =>
      _StatisticalDataPresentationState();
}

class _StatisticalDataPresentationState
    extends State<StatisticalDataPresentation> {
  late ZoomPanBehavior zoomPanBehavior;
  static const double titleFontSize = 17;

  void notifyAll() {
    setState(() {});
    widget.notifyParent();
  }

  @override
  void initState() {
    GraphDataLists.notifyParent = notifyAll;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: MediaQuery.of(context).size.width - 20,
        // height: MediaQuery.of(context).size.height / 2,
        child: GridView.count(
          mainAxisSpacing: 3,
          crossAxisSpacing: 3,
          crossAxisCount: 2,
          children: [
            AspectRatio(
              aspectRatio: 1.0,
              child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          const Text(
                            "Temp. maksymalna",
                            textAlign: TextAlign.center,
                            // maxLines: 1,
                            style: TextStyle(fontSize: titleFontSize),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                GraphDataLists.currentTempList.valMax.value
                                    .toStringAsFixed(0),
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                              const Text(
                                " \u2103",
                                style: TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          const Text(
                            "Zarejestrowano o czasie",
                            textAlign: TextAlign.center,
                            maxLines: 1,
                          ),
                          Text(
                            "${GraphDataLists.currentTempList.valMax.time.toStringAsFixed(0)} s",
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 25,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            AspectRatio(
              aspectRatio: 1.0,
              child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          const Text(
                            "Temp. minimalna",
                            textAlign: TextAlign.center,
                            // maxLines: 1,
                            style: TextStyle(fontSize: titleFontSize),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                GraphDataLists.currentTempList.valMin.value >
                                        40
                                    ? "---"
                                    : GraphDataLists
                                        .currentTempList.valMin.value
                                        .toStringAsFixed(0),
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                              const Text(
                                " \u2103",
                                style: TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          const Text(
                            "Zarejestrowano o czasie",
                            textAlign: TextAlign.center,
                            maxLines: 1,
                          ),
                          Text(
                            "${GraphDataLists.currentTempList.valMin.time.toStringAsFixed(0)} s",
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 25,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            AspectRatio(
              aspectRatio: 1.0,
              child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          const Text(
                            "Temp. średnia",
                            textAlign: TextAlign.center,
                            // maxLines: 1,
                            style: TextStyle(fontSize: titleFontSize),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                GraphDataLists.currentTempList.valAvg
                                    .toStringAsFixed(2),
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                              const Text(
                                " \u2103",
                                style: TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            AspectRatio(
              aspectRatio: 1.0,
              child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          const Text(
                            "Prąd maksymalny",
                            textAlign: TextAlign.center,
                            // maxLines: 1,
                            style: TextStyle(fontSize: titleFontSize),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                GraphDataLists.controlCurrentList.valMax.value
                                    .toStringAsFixed(1),
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                              const Text(
                                " mA",
                                style: TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          const Text(
                            "Zarejestrowano o czasie",
                            textAlign: TextAlign.center,
                            maxLines: 1,
                          ),
                          Text(
                            "${GraphDataLists.controlCurrentList.valMax.time.toStringAsFixed(0)} s",
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 25,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            AspectRatio(
              aspectRatio: 1.0,
              child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          const Text(
                            "Prąd minimalny",
                            textAlign: TextAlign.center,
                            // maxLines: 1,
                            style: TextStyle(fontSize: titleFontSize),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                GraphDataLists.controlCurrentList.valMin.value >
                                    40
                                    ? "---"
                                    : GraphDataLists
                                    .controlCurrentList.valMin.value
                                    .toStringAsFixed(1),
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                              const Text(
                                " mA",
                                style: TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          const Text(
                            "Zarejestrowano o czasie",
                            textAlign: TextAlign.center,
                            maxLines: 1,
                          ),
                          Text(
                            "${GraphDataLists.currentTempList.valMin.time.toStringAsFixed(0)} s",
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 25,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            AspectRatio(
              aspectRatio: 1.0,
              child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          const Text(
                            "Prąd średni",
                            textAlign: TextAlign.center,
                            // maxLines: 1,
                            style: TextStyle(fontSize: titleFontSize),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                GraphDataLists.controlCurrentList.valAvg
                                    .toStringAsFixed(1),
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                              const Text(
                                " mA",
                                style: TextStyle(
                                  fontSize: 35,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
