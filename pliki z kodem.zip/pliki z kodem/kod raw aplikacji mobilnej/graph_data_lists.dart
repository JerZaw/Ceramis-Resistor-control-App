import 'live_data.dart';

class GraphDataLists {
  static Function()? notifyParent;

  static LiveDataList goalTempList = LiveDataList();
  static LiveDataList currentTempList = LiveDataList();
  static LiveDataList controlPWMList = LiveDataList();
  static LiveDataList controlCurrentList = LiveDataList();
  static int currentTemperature = 0;
  static double currentOnResistor = 0;
  static double controlPWM = 0;
  static bool controlOn = false;
}
