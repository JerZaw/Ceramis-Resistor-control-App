import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'graph_data_lists.dart';

Future<int> mqttSetup(
  MqttServerClient client,
) async {
  /// Set the correct MQTT protocol for mosquito
  client.setProtocolV311();

  /// Add the unsolicited disconnection callback
  client.onDisconnected = onDisconnected;

  /// Add the successful connection callback
  client.onConnected = onConnected;

  /// Add a subscribed callback
  client.onSubscribed = onSubscribed;

  /// Create a connection message to use or use the default one. The default one sets the
  /// client identifier, any supplied username/password and clean session,
  /// an example of a specific one below.
  final connMess = MqttConnectMessage()
      .withClientIdentifier('jerzix-raspberry-python')
      .withWillTopic('willtopic') // If you set this you must set a will message
      .withWillMessage('My Will message')
      .startClean() // Non persistent session for testing
      .withWillQos(MqttQos.atLeastOnce);
  if (kDebugMode) {
    print('EXAMPLE::Mosquitto client connecting....');
  }
  client.connectionMessage = connMess;

  /// Connect the client, any errors here are communicated by raising of the appropriate exception. Note
  /// in some circumstances the broker will just disconnect us, see the spec about this, we however will
  /// never send malformed messages.
  try {
    await client.connect();
  } on NoConnectionException catch (e) {
    // Raised by the client when connection fails.
    if (kDebugMode) {
      print('EXAMPLE::client exception - $e');
    }
    client.disconnect();
  } on SocketException catch (e) {
    // Raised by the socket layer
    if (kDebugMode) {
      print('EXAMPLE::socket exception - $e');
    }
    client.disconnect();
  }

  /// Check we are connected
  if (client.connectionStatus!.state == MqttConnectionState.connected) {
    if (kDebugMode) {
      print('EXAMPLE::Mosquitto client connected');
    }
  } else {
    /// Use status here rather than state if you also want the broker return code.
    if (kDebugMode) {
      print(
          'EXAMPLE::ERROR Mosquitto client connection failed - disconnecting, status is ${client.connectionStatus}');
    }
    client.disconnect();
    exit(-1);
  }

  /// Ok, lets try a subscription
  if (kDebugMode) {
    print('Subscribing to the jerzix/mis/raspberry/data topic');
  }
  const topic = 'jerzix/mis/raspberry/data'; // Not a wildcard topic
  client.subscribe(topic, MqttQos.atMostOnce);

  /// The client has a change notifier object(see the Observable class) which we then listen to to get
  /// notifications of published updates to each subscribed topic.
  client.updates!.listen((List<MqttReceivedMessage<MqttMessage?>>? c) {
    final recMess = c![0].payload as MqttPublishMessage;
    final pt =
        MqttPublishPayload.bytesToStringAsString(recMess.payload.message);

    /// The above may seem a little convoluted for users only interested in the
    /// payload, some users however may be interested in the received publish message,
    /// lets not constrain ourselves yet until the package has been in the wild
    /// for a while.
    /// The payload is a byte buffer, this will be specific to the topic
    // if (kDebugMode) {
    //   print(
    //     'EXAMPLE::Change notification:: topic is <${c[0].topic}>, payload is <-- $pt -->');
    // }
    onMessage(pt);
  });

  /// Lets publish to our topic
  /// Use the payload builder rather than a raw buffer
  /// Our known topic to publish to
  // const pubTopic = 'jerzix/mis/android/';
  // final builder = MqttClientPayloadBuilder();
  // builder.addString('Hello from mqtt_client');
  // client.publishMessage(pubTopic, MqttQos.exactlyOnce, builder.payload!);

  return 0;
}

void onMessage(String body) {
// {"current_temperature": 27, "goal_temperature": 27, "control_PWM": 0, "control_current": 0, "timestamp": 0}
  var messageData = jsonDecode(body);

  GraphDataLists.currentTemperature = messageData["current_temperature"];
  GraphDataLists.currentTempList.addDataPoint(
      messageData["current_temperature"].toDouble(),
      messageData["timestamp"].toDouble());

  if (GraphDataLists.controlOn) {
    GraphDataLists.goalTempList.addDataPoint(
        messageData["goal_temperature"].toDouble(),
        messageData["timestamp"].toDouble());
  } else {
    GraphDataLists.goalTempList
        .addDataPoint(0, messageData["timestamp"].toDouble());
  }

  GraphDataLists.currentOnResistor = messageData["control_current"].toDouble();
  GraphDataLists.currentOnResistor =
      double.parse(GraphDataLists.currentOnResistor.toStringAsFixed(1));
  GraphDataLists.controlCurrentList.addDataPoint(
      messageData["control_current"].toDouble(),
      messageData["timestamp"].toDouble());

  GraphDataLists.controlPWM = messageData["control_PWM"].toDouble();
  GraphDataLists.controlPWM =
      double.parse(GraphDataLists.controlPWM.toStringAsFixed(1));
  GraphDataLists.controlPWMList.addDataPoint(
      messageData["control_PWM"].toDouble(),
      messageData["timestamp"].toDouble());

  GraphDataLists.notifyParent!();
}

/// The subscribed callback
void onSubscribed(String topic) {
  if (kDebugMode) {
    print('EXAMPLE::Subscription confirmed for topic $topic');
  }
}

/// The unsolicited disconnect callback
void onDisconnected() {
  if (kDebugMode) {
    print('EXAMPLE::OnDisconnected client callback - Client disconnection');
  }
}

/// The successful connect callback
void onConnected() {
  if (kDebugMode) {
    print(
        'EXAMPLE::OnConnected client callback - Client connection was successful');
  }
}

int customPublish(String topic, String data, MqttServerClient client) {
  const baseTopic = 'jerzix/mis/android/';
  final builder = MqttClientPayloadBuilder();
  builder.addString(data);
  return client.publishMessage(
      baseTopic + topic, MqttQos.exactlyOnce, builder.payload!);
}

int toInt(bool val) => val ? 1 : 0;
