#!/home/jerzix/.venv/mis_projekt/mis_venv/bin/python

import time
import board
import adafruit_dht
import psutil
import RPi.GPIO as GPIO
import paho.mqtt.client as mqtt

import mqttManagement
from pid import PID

# We first check if a libgpiod process is running. If yes, we kill it!
for proc in psutil.process_iter():
    if proc.name() == 'libgpiod_pulsein' or proc.name() == 'libgpiod_pulsei':
        proc.kill()

#setup
sensor = adafruit_dht.DHT11(board.D16) #using a GPIO16 according to a default raspberry 4B pinout

resistorpin = 12 #using GPIO12 (PWM0) for the resistor control
GPIO.setup(resistorpin,GPIO.OUT) #define the behaviour of the resistorpin as output
GPIO.setwarnings(False) #ignore the warnings
pwm = GPIO.PWM(resistorpin,1000) #create the pwm instance with frequency 1000 Hz
pwm.start(0) #start the pwm at 0 duty cycle

mqttManagement.goal_temperature = 0
mqttManagement.control_start = 0
mqttManagement.data_interval = 2
current_temperature = 0
timestamp = 0
control_PWM = 0
control_current = 0
my_client = mqtt.Client()
mqttManagement.mqtt_setup(my_client)

file_path = "temp_data.txt"
with open(file_path, 'w') as file:
    pass 

kp = 16.4663
ki = 0.058784
kd = 1153.1284
pid = PID(kp, ki, kd, setpoint=0)

pid.output_limits = (0,100)
pid.sample_time = 2

def log_temperature(temperature, timestamp, PWM_signal, file_path):
    # Create a string to write to the file
    log_entry = f"{timestamp};{temperature};{PWM_signal}\n"

    # Open the file in 'a' mode (append) to add the log entry to the end of the file
    with open(file_path, 'a') as file:
        file.write(log_entry)

#main loop
while True:
    # reading temperature segment with catching errors
    try:
        current_temperature = sensor.temperature
        timestamp = round(time.time() - mqttManagement.start_time, 1)
        log_temperature(current_temperature, timestamp, control_PWM, file_path)
    except RuntimeError as error:
        print(error.args[0])
        time.sleep(2.0)
        continue
    except Exception as error:
        sensor.exit()
        raise error

    # control of the resistor segment
    if pid.setpoint != mqttManagement.goal_temperature:
        pid.setpoint = mqttManagement.goal_temperature
    if mqttManagement.control_start == 1:
        control_PWM = pid(current_temperature)
    else:
        control_PWM = 0
    
    control_current = 1.5597 * control_PWM
    pwm.ChangeDutyCycle(control_PWM)

    print(f"if_PWM_active: {mqttManagement.control_start} \t PWM_duty_cycle: {control_PWM} \t goal_temperature: {mqttManagement.goal_temperature}  current_temperature: {current_temperature} timestamp: {timestamp}")
    mqttManagement.send_data(my_client, current_temperature, control_PWM, control_current, timestamp) 
    
    time.sleep(mqttManagement.data_interval) #how long to wait for the next loop