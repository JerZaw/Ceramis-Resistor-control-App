import time
import json
from random import randint
import paho.mqtt.client as mqtt
import urllib.request

global goal_temperature 
global control_start
global data_interval
global start_time

# listening for the goal_temperature data from android app
def on_connect(client, userdata, flags, rc):
    if rc==0:
        print("MQTT connected clien_pos OK Returned code=",rc)
        client.subscribe("jerzix/mis/android/#")
    else:
        print("Bad connection Returned code=",rc)

# reading the goal_temperature
def on_message(client, userdata, message):
    print(f"message topic  {message.topic}")
    print("message received  "  ,str(message.payload.decode("utf-8")))
    json_data = json.loads(message.payload.decode("utf-8"))
    
    if message.topic == "jerzix/mis/android/temperature":
        # if control_start == 1:
        global goal_temperature 
        goal_temperature = json_data['goal_temperature']
        print(f"goal_temperature = {goal_temperature}")
    elif message.topic == "jerzix/mis/android/control":
        global control_start
        control_start = json_data['control_start']
        if json_data['should_reset'] == 1:
            global start_time
            start_time = time.time()
        print(f"control_start = {control_start}")
    elif message.topic == "jerzix/mis/android/dataInterval":
        global data_interval
        data_interval = json_data['data_interval']
        print(f"data_interval = {data_interval}")
    

# sending the {"current_temperature": 27, "goal_temperature": 27, "control_PWM": 0, "control_current": 0, "timestamp": 0}
def send_data(client, current_temperature, control_PWM, control_current, timestamp):
    dataJson = json.dumps({"current_temperature" : current_temperature,
                           "goal_temperature": goal_temperature,"control_PWM" : control_PWM,
                           "control_current" : control_current, "timestamp": timestamp})
    client.publish("jerzix/mis/raspberry/data",dataJson)

def wait_for_internet_connection():
    while True:
        try:
            response = urllib.request.urlopen("https://test.mosquitto.org/",timeout=5)
            return
        except urllib.request.HTTPError:
            pass

# MQTT main setup
def mqtt_setup(my_client):
    broker_address="test.mosquitto.org" #name of the free mqtt broker

    my_client.on_connect = on_connect
    my_client.on_message = on_message

    global start_time
    start_time = time.time()



    my_client.connect(broker_address, 1883, 60)
    my_client.loop_start()
